"Default_Material" is the default material that will be used when you create a new Water2D object.
If you want to use a different default material, open the Water2D_Tool script and edit
the name of the material in the SetDefaultMaterial method (line 338).
The default material must always be placed in the Resources folder, otherwise you will get an error
when creating a new Water2D object.